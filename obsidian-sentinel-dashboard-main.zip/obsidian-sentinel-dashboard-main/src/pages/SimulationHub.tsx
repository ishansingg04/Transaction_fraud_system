import { useState } from "react";
import { entities, simulationDirectives } from "@/data/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Zap, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

interface SimResult {
  riskScore: number;
  status: "COMPLETED" | "FLAGGED" | "BLOCKED";
  directives: string[];
  alertId: string | null;
}

const SimulationHub = () => {
  const [result, setResult] = useState<SimResult | null>(null);
  const [animatedRisk, setAnimatedRisk] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const score = Math.floor(Math.random() * 100);
    const status = score >= 75 ? "BLOCKED" : score >= 40 ? "FLAGGED" : "COMPLETED";
    const numDirectives = score >= 75 ? 4 : score >= 40 ? 2 : 0;
    const directives = simulationDirectives.slice(0, numDirectives);
    const alertId = score >= 75 ? `SYS-ALT-${Math.floor(Math.random() * 9000 + 1000)}` : null;

    setResult({ riskScore: score, status, directives, alertId });
    setAnimatedRisk(0);
    let current = 0;
    const interval = setInterval(() => {
      current += 2;
      if (current >= score) {
        setAnimatedRisk(score);
        clearInterval(interval);
      } else {
        setAnimatedRisk(current);
      }
    }, 20);
  };

  const riskColor = animatedRisk >= 75 ? "bg-destructive" : animatedRisk >= 40 ? "bg-fw-amber" : "bg-fw-emerald";
  const statusIcon = result?.status === "COMPLETED" ? <CheckCircle className="w-5 h-5 text-fw-emerald" /> : result?.status === "FLAGGED" ? <AlertTriangle className="w-5 h-5 text-fw-amber" /> : <XCircle className="w-5 h-5 text-destructive" />;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
      {/* Form */}
      <div className="glass-card p-6">
        <h3 className="font-heading font-semibold text-foreground mb-5 flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" /> Inject Simulation Vector
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Target Entity</Label>
            <Select defaultValue={entities[0]}>
              <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue /></SelectTrigger>
              <SelectContent>{entities.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Volume (₹)</Label>
            <Input type="number" placeholder="Enter amount" defaultValue="1250000" className="bg-secondary/50 border-border/50" />
          </div>
          <div>
            <Label className="text-muted-foreground text-xs mb-1.5 block">Protocol</Label>
            <Select defaultValue="Credit">
              <SelectTrigger className="bg-secondary/50 border-border/50"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Debit">Debit</SelectItem>
                <SelectItem value="Credit">Credit</SelectItem>
                <SelectItem value="Transfer">Transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Origin IP</Label>
              <Input placeholder="0.0.0.0" defaultValue="103.24.78.12" className="bg-secondary/50 border-border/50" />
            </div>
            <div>
              <Label className="text-muted-foreground text-xs mb-1.5 block">Geofence</Label>
              <Input placeholder="City, Country" defaultValue="Mumbai, IN" className="bg-secondary/50 border-border/50" />
            </div>
          </div>
          <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
            <Zap className="w-4 h-4 mr-1" /> Execute Transfer
          </Button>
        </form>
      </div>

      {/* Results */}
      <div className="glass-card p-6">
        <h3 className="font-heading font-semibold text-foreground mb-5">Engine Telemetry</h3>
        {!result ? (
          <div className="flex items-center justify-center h-64 text-muted-foreground text-sm">
            Execute a simulation to view telemetry...
          </div>
        ) : (
          <div className="space-y-5 animate-scale-in">
            {/* Risk Meter */}
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-xs text-muted-foreground">Risk Assessment</span>
                <span className="text-sm font-mono font-bold text-foreground">{animatedRisk}%</span>
              </div>
              <div className="relative h-3 w-full rounded-full bg-secondary overflow-hidden">
                <div className={`h-full rounded-full transition-all duration-300 ${riskColor}`} style={{ width: `${animatedRisk}%` }} />
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/40 border border-border/30">
              {statusIcon}
              <div>
                <p className="text-xs text-muted-foreground">Clearance Status</p>
                <p className="font-heading font-bold text-foreground">{result.status}</p>
              </div>
            </div>

            {/* Directives */}
            {result.directives.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">Triggered Directives</p>
                <div className="space-y-2">
                  {result.directives.map((d, i) => (
                    <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg bg-destructive/5 border border-destructive/20 text-xs text-foreground">
                      <AlertTriangle className="w-3.5 h-3.5 text-destructive mt-0.5 flex-shrink-0" />
                      {d}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Alert ID */}
            {result.alertId && (
              <div className="p-3 rounded-lg border border-destructive/40 bg-destructive/10 shadow-[0_0_20px_-5px_hsl(0_84%_60%/0.3)] text-center">
                <p className="text-xs text-muted-foreground mb-1">System Alert ID</p>
                <p className="font-mono font-bold text-destructive text-lg animate-glow-pulse">{result.alertId}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SimulationHub;
